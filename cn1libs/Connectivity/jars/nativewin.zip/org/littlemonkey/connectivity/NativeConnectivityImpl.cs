namespace org.littlemonkey.connectivity{

using System;
using System.Windows;

public class NativeConnectivityImpl {
    public int getConnectionStatus() {
        return 0;
    }

    public bool isSupported() {
        return false;
    }

}
}
