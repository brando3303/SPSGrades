package org.littlemonkey.connectivity;

public class NativeConnectivityImpl implements org.littlemonkey.connectivity.NativeConnectivity{
    public int getConnectionStatus() {
        return 0;
    }

    public boolean isSupported() {
        return false;
    }

}
